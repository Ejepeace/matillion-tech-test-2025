package com.matillion.techtest2025.controller;

import com.matillion.techtest2025.controller.response.DataAnalysisResponse;
import com.matillion.techtest2025.controller.response.DataHealthResponse;
import com.matillion.techtest2025.repository.DataAnalysisRepository;
import com.matillion.techtest2025.service.DataAnalysisService;
import com.matillion.techtest2025.service.DataHealthService;
import com.matillion.techtest2025.repository.entity.DataAnalysisEntity;
import com.matillion.techtest2025.model.ColumnStatistics;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/analysis")
public class DataAnalysisController {
    private final DataAnalysisService dataAnalysisService;
    private final DataAnalysisRepository dataAnalysisRepository;
    private final DataHealthService dataHealthService;
    
    public DataAnalysisController(DataAnalysisService dataAnalysisService, 
                                 DataAnalysisRepository dataAnalysisRepository,
                                 DataHealthService dataHealthService) {
        this.dataAnalysisService = dataAnalysisService;
        this.dataAnalysisRepository = dataAnalysisRepository;
        this.dataHealthService = dataHealthService;
    }
    
    @PostMapping("/ingestCsv")
    public ResponseEntity<DataAnalysisResponse> ingestCsv(@RequestBody String csvData) {
        DataAnalysisEntity entity = dataAnalysisService.analyzeCsv(csvData);
        DataAnalysisEntity savedEntity = dataAnalysisRepository.save(entity);
        return ResponseEntity.ok(new DataAnalysisResponse(
            savedEntity.getNumberOfRows(),
            savedEntity.getNumberOfColumns(),
            savedEntity.getTotalCharacters(),
            savedEntity.getColumnStatistics().stream()
                .map(stat -> new ColumnStatistics(stat.getColumnName(), stat.getNullCount(), stat.getUniqueCount()))
                .collect(Collectors.toList()),
            savedEntity.getCreatedAt()
        ));
    }

    @GetMapping("/{id}")
    public ResponseEntity<DataAnalysisResponse> getAnalysis(@PathVariable Long id) {
        return dataAnalysisRepository.findById(id)
                .map(entity -> ResponseEntity.ok(convertToResponse(entity)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAnalysis(@PathVariable Long id) {
        if (dataAnalysisRepository.existsById(id)) {
            dataAnalysisRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Part 3: Health Score Endpoint
    @GetMapping("/{id}/health")
    public ResponseEntity<DataHealthResponse> getDataHealth(@PathVariable Long id) {
        return dataAnalysisRepository.findById(id)
                .map(entity -> {
                    int healthScore = dataHealthService.calculateHealthScore(entity);
                    String healthStatus = dataHealthService.getHealthStatus(healthScore);
                    
                    int totalCells = entity.getNumberOfRows() * entity.getNumberOfColumns();
                    int totalNulls = entity.getColumnStatistics().stream()
                            .mapToInt(stat -> stat.getNullCount())
                            .sum();
                    double completeness = totalCells > 0 ? 
                        ((double) (totalCells - totalNulls) / totalCells) * 100 : 0;
                    
                    return ResponseEntity.ok(new DataHealthResponse(
                        entity.getId(),
                        healthScore,
                        Math.round(completeness * 100.0) / 100.0,
                        healthStatus
                    ));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    private DataAnalysisResponse convertToResponse(DataAnalysisEntity entity) {
        return new DataAnalysisResponse(
            entity.getNumberOfRows(),
            entity.getNumberOfColumns(),
            entity.getTotalCharacters(),
            entity.getColumnStatistics().stream()
                .map(stat -> new ColumnStatistics(stat.getColumnName(), stat.getNullCount(), stat.getUniqueCount()))
                .collect(Collectors.toList()),
            entity.getCreatedAt()
        );
    }
}
