package com.matillion.techtest2025.controller.response;

public record DataHealthResponse(
        Long analysisId,
        int healthScore,
        double completenessPercentage,
        String healthStatus
) {}
