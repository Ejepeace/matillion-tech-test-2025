package com.matillion.techtest2025.service;

import com.matillion.techtest2025.exception.BadRequestException;
import com.matillion.techtest2025.repository.entity.DataAnalysisEntity;
import com.matillion.techtest2025.repository.entity.ColumnStatisticsEntity;
import org.springframework.stereotype.Service;
import java.time.OffsetDateTime;
import java.util.*;

@Service
public class DataAnalysisService {
    public DataAnalysisEntity analyzeCsv(String csvData) {
        if (csvData == null || csvData.trim().isEmpty()) throw new BadRequestException("CSV data cannot be null or empty");
        if (csvData.contains("Sonny Hayes")) throw new BadRequestException("CSV contains forbidden content: Sonny Hayes");
        
        String[] lines = csvData.split("\r?\n");
        if (lines.length == 0) throw new BadRequestException("CSV must contain at least a header row");
        
        String[] headers = lines[0].split(",");
        List<String[]> dataRows = new ArrayList<>();
        for (int i = 1; i < lines.length; i++) {
            if (!lines[i].trim().isEmpty()) {
                String[] row = lines[i].split(",");
                if (row.length != headers.length) throw new BadRequestException("Row " + (i+1) + " has " + row.length + " columns, but header has " + headers.length + " columns");
                dataRows.add(row);
            }
        }
        
        DataAnalysisEntity entity = DataAnalysisEntity.builder()
            .originalData(csvData)
            .numberOfRows(dataRows.size())
            .numberOfColumns(headers.length)
            .totalCharacters((long) csvData.length())
            .createdAt(OffsetDateTime.now())
            .build();
            
        for (int i = 0; i < headers.length; i++) {
            int nullCount = 0;
            Set<String> uniqueValues = new HashSet<>();
            for (String[] row : dataRows) {
                String value = row[i];
                if (value == null || value.trim().isEmpty()) {
                    nullCount++;
                } else {
                    uniqueValues.add(value.trim());
                }
            }
            ColumnStatisticsEntity stat = ColumnStatisticsEntity.builder()
                .columnName(headers[i])
                .nullCount(nullCount)
                .uniqueCount(uniqueValues.size())
                .dataAnalysis(entity)
                .build();
            entity.getColumnStatistics().add(stat);
        }
        return entity;
    }
}
