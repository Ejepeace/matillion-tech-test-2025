package com.matillion.techtest2025.service;

import com.matillion.techtest2025.repository.entity.DataAnalysisEntity;
import org.springframework.stereotype.Service;

@Service
public class DataHealthService {
    
    public int calculateHealthScore(DataAnalysisEntity entity) {
        if (entity.getNumberOfRows() == 0) return 0;
        
        int totalNulls = entity.getColumnStatistics().stream()
                .mapToInt(stat -> stat.getNullCount())
                .sum();
        
        int totalCells = entity.getNumberOfRows() * entity.getNumberOfColumns();
        double completeness = ((double) (totalCells - totalNulls) / totalCells) * 100;
        
        if (completeness >= 95) return 100;
        if (completeness >= 80) return 75;
        if (completeness >= 60) return 50;
        return 25;
    }
    
    public String getHealthStatus(int score) {
        if (score >= 90) return "EXCELLENT";
        if (score >= 70) return "GOOD";
        if (score >= 50) return "FAIR";
        return "POOR";
    }
}
